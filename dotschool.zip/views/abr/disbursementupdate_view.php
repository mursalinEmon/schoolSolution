        <div class="page-wrapper">
                <div class="page-title">
                
                            <div class="panel panel-default">
                                <div class="panel-head">
                                    <div class="panel-title">
                                        <span class="panel-title-text">Disbursement Update</span>
                                        
                                    </div>
                                </div>
                                
                            </div>
                          
                </div>
                <div class="page-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="panel panel-default">
                                <div class="panel-head">
                                    <div class="panel-title">
                                        <div id="resultalert" class="alert alert-dark">
                                        Disbursement Update
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    
                                    <form id="customerform">
                                        <div class="row">
                                        <div class="col-4">
                                                <div>
                                                    <label for="confcodetype">Bank</label>
                                                    <select class="form-control form-control-sm" id="bank" name="bank">
                                                    <option value="Nagad">Nagad</option>
                                                    <option value="Bkash">Bkash</option>
                                                    </select>
                                                    
                                                </div>
                                            </div>
                                            

                                            <div class="col-4">
                                                <div>
                                                    <label id="rin">Account No</label>
                                                    <input type="text" class="form-control form-control-sm" id="accno" name="accno" placeholder="Account No">
                                                   
                                                </div>
                                            </div>  

                                            <div class="col-4">
                                                <div>
                                                    <label id="rin">Txn No</label>
                                                    <input type="text" class="form-control form-control-sm" id="txnno" name="txnno" placeholder="Txn No">
                                                </div>
                                            </div>                                          
                                            <div class="col-4">
                                                <div>
                                                    <label id="rin">Confirmation No</label>
                                                    <input type="text" class="form-control form-control-sm" id="confno" name="confno" placeholder="Confirmation No">
                                                </div>
                                            </div>                                          
                                        </div>
                                        
                                    </form>
                                    <div class="panel-footer text-right">
                                    <button class="btn btn-primary mr-2" id="checkout">Update Information</button>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>    
</div>