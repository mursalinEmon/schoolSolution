<div class="page-wrapper">
                    <div class="page-title">
                              <!-- <input type="hidden" value="<?php //echo $this->token; ?>" id="token">       -->
                              <h1>Generation Tree</h1>
                        </div>
                        <div class="col-12">
                                    
                                    <div class="tab-content">
                                        
                                        <div class="tab-pane active" id="generation1">
                                            <div class="panel">
                                                <div class="panel-body">                                                
                                                    <div class="row no-gutters">
                                                        
                                                        <div class="col-3">
                                                            <div class="input-group">
                                                                <select class="form-control form-control-sm" id="gentype">
                                                                    <option>Generation 1</option>
                                                                    <option>Generation 2</option>
                                                                    <option>Generation 3</option>
                                                                    <option>Generation 4</option>
                                                                    <option>Generation 5</option>                                                        
                                                                </select>
                                                            </div>                                            
                                                        </div>
                                                        
                                                        <div class="col-3 ml">
                                                                <button  id="searchtxn"  class="btn btn-sm btn-primary btn-pill ml-1"><i class="fa fa-search mr-1"></i>Search</button>
                                                        </div>
                                             
                                                        <div class="col-12 mt-4">
                                                            <table id="gentable"  cellspacing="0" width="100%">

                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        
                            </div>
                                
                                 
                                
                        </div>
                        
</div>