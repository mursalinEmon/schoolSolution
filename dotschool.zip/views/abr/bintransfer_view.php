        <div class="page-wrapper">
                <div class="page-title">
                
                            <div class="panel panel-default">
                                <div class="panel-head">
                                    <div class="panel-title">
                                        <span class="panel-title-text">BIN Transfer</span>
                                        
                                    </div>
                                </div>
                                
                            </div>
                          
                </div>
                <div class="page-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="panel panel-default">
                                <div class="panel-head">
                                    <div class="panel-title">
                                        <div id="resultalert" class="alert alert-dark">
                                        BIN Transfer
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    
                                    <form id="customerform">
                                        <div class="row">
                                        <div class="col-4">
                                        <div>
                                                    <label id="rin">BIN To Transfer</label>
                                                    <input type="text" class="form-control form-control-sm" id="bin" name="bin" placeholder="BIN To Transfer">
                                                    <p class="form-text text-danger">Name: <span  id="binname"></span></p>
                                                </div>
                                            </div>
                                            

                                            <!-- <div class="col-4">
                                                <div>
                                                    <label>TO RIN</label>
                                                    <input type="text" class="form-control form-control-sm" id="torin" name="torin" placeholder="To RIN">
                                                    <p class="form-text text-danger">Name: <span  id="rinname"></span></p>
                                                </div>
                                            </div>   -->

                                            <div class="col-4">
                                                <div>
                                                    <label id="rin">Txn No</label>
                                                    <input type="text" class="form-control form-control-sm" id="txnno" name="txnno" placeholder="Txn No">
                                                </div>
                                            </div>                                          
                                            <div class="col-4">
                                                <div>
                                                    <label id="rin">Confirmation No</label>
                                                    <input type="text" class="form-control form-control-sm" id="confno" name="confno" placeholder="Confirmation No">
                                                </div>
                                            </div>                                          
                                        </div>
                                        
                                    </form>
                                    <div class="panel-footer text-right">
                                    <button class="btn btn-primary mr-2" id="checkout">Transfer</button>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>    
</div>