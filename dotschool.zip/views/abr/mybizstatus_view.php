<div class="page-wrapper">
                <div class="page-title">
                
                            <div class="panel panel-default">
                                <div class="panel-head">
                                    <div class="panel-title">
                                        <span class="panel-title-text">My BIN Required BV</span>
                                        
                                    </div>
                                </div>
                                
                            </div>
                          
                </div>
                <div class="page-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-head">
                                    <div class="panel-title">
                                        <span class="panel-title-text">My BIN List</span>
                                    </div>
                                     <!-- <div class="panel-action">
                                        <button class="btn btn-primary btn-shadow btn-gradient btn-sm btn-pill">View All</button>
                                    </div>  -->
                                </div>
                                <div class="panel-wrapper">
                                    <table id="bintable"  cellspacing="0" width="100%">
                                       
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                        </div>
                    </div>
                </div>    
</div>