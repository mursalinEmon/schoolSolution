
    <div class="page-body">
        <div class="row">
        <div class="col-3">
        </div>
            <div class="col-6">
                 
                    
                    <div class="portlet portlet-primary">
              
                
                    <div class="portlet-head">
                        <div class="portlet-title">                      
                            
                            <span class="portlet-title-text"><strong>Password Recovery</strong></span>
                        </div>
                    </div>
                    <div class="portlet-wrapper">
                        <div class="portlet-body">
                            <div class="alert alert-primary" id="result">
                                Recover your password by sms!
                            </div>
                            <form id="sendpassform">
                    <div>
                        <input type="text" name="rin" class="form-control form-control-sm" id="rin" autocomplete="on" required>
                        <span class="form-highlight"></span>
                        <span class="form-bar"></span>
                        <label class="float-label" >RIN</label>
                    </div>
                    <div>
                        <input type="text" name="mobile" class="form-control form-control-sm" id="mobile" placeholder="01XXXXXXXXX" autocomplete="on" required>
                        <span class="form-highlight"></span>
                        <span class="form-bar"></span>
                        <label class="float-label" >Mobile (11 Digit)</label>
                    </div>
                        <button class="btn btn-success btn-pill" type="submit" id="btnsendpass"><strong><i class="far fa-arrow-alt-circle-left"></i>&nbsp;Send Password</strong></button>
                    </form>
                    </div>
                    </div>
                    <div>
                    <div class="portlet-body">    
                    <a href="<?php echo URL;?>" class="btn btn-primary btn-pill"><strong><i class="far fa-arrow-alt-circle-left"></i>&nbsp;Go Back</strong></a>
                    </div>
                    </div>
                </div>
            </div>
            <div class="col-3">
            </div>
        </div>
    </div>
