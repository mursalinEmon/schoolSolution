<div id="menuheader" class="border-bottom">
    <div class="container-fluid">
        <span id="caption">List Item 1</span>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2">
        <ul class="nav flex-column">
  <li class="nav-item">
    <a class="nav-link active" href="#">Active</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Dropdown link
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
</ul>
        
      </div>
        <div class="col-lg-9">
            <div class="border">
                <div id="wrapper" class="border-bottom">
                    <div id="filter" >
                        <div class="form-inline">
                            <div class="form-group">
                              <input class="form-control form-control-sm" type="text" placeholder="Txn No">
                            </div>
                            <div id="filterinput" class="form-group">
                              <input class="form-control form-control-sm" type="text" placeholder="Customer">
                            </div>
                            <div id="filterinput" class="form-group">
                              <input class="form-control form-control-sm" type="text" placeholder="Mobile">
                            </div>
                            <div id="filterinput" class="form-group">
                              <input class="form-control form-control-sm" type="text" placeholder="Email">
                            </div>  
                            <div id="filterinput" class="form-group">
                            <button class="form-control form-control-sm">Search</button>                      
                            </div>                            
                          </div>                          
                      </div>
                      
                  </div>        
                  <div id="filter" class="row">
                    <div class="form-inline col-lg-10">
                      <div class="form-group">
                        <input class="form-control form-control-sm" type="text" placeholder="Select">
                      </div>
                    </div>
                    <div class="col-lg-2">
                      <button class="form-control form-control-sm">+Create New</button>                      
                    </div>
                  </div>
                <div id="list">          
                    <table class="table table-sm table-bordered table-hover">
                      <thead class="">
                          <th>SL</th>
                          <th>Trxno</th>  
                          <th>Date</th>
                          <th>Customer</th>
                          <th>Phone</th>
                          <th>Amount</th>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Txn-000001</td>
                          <td>11-05-2018</td>
                          <td>ABC Customer</td>
                          <td>01841923270</td>
                          <td>3244</td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td>Txn-000001</td>
                          <td>11-05-2018</td>
                          <td>ABC Customer</td>
                          <td>01841923270</td>
                          <td>3244</td>
                        </tr>
                      </tbody>  
                    </table>          
                  </div>
                  <div id="listfooter" class="form-inline border-top">
                    <button class="form-control form-control-sm">25</button>
                    <button class="form-control form-control-sm">50</button>
                    <button class="form-control form-control-sm">100</button>
                  </div>
        </div>
    </div>
      <div class="col-md-1 smlinks">
      
      </div>
      
    </div>

    
</div>