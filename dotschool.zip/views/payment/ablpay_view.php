
   
   <div class="page-title">
    </div>
    <div class="page-body">
        <div class="row">
            <div class="col-lg-4">
                
            </div>
            <div class="col-lg-4">
                <div class="panel panel default">
                    <div class="panel-head bg-primary">
                        <div class="panel-title">
                            <span class="panel-title-text text-white">ABL Purchase Account</span>
                        </div>
                    </div>
                    <?php echo $this->html;?>
                    
                </div>
            </div>
            <div class="col-lg-4">
                
            </div>
            
        </div>
    </div>
