
        
         <!-- Start Portfolio Section -->
         <div class="layer-stretch">
         <div class="pt-4">
            <div class="row align-items-center shop-filter">
                            <div class="col-sm-4">
                                <h3>Photo Gallery UNITED ASSOCIATES</h3>
                            </div>
                            <div class="col-sm-8 text-right">
                                <p class="m-0">Showing 1–10 of 55 results</p>
                            </div>
                        </div>
            <div class="layer-wrapper pb-20">
                <div class="portfolio-wrapper pt-4">
                    <ul class="row portfolio-masonary">
                        <li class="col-md-6 col-lg-4 portfolio-img filter all mobile web design graphics">
                            <figure class="effect-zoe">
                                <img src="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" alt=""/>
                                <figcaption>
                                    <p class="title">John <span>Doe</span></p>
                                    <p class="icon">
                                        
                                        <a href="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" class="portfolio-gallery" title="John Doe"><i class="icon-size-fullscreen"></i></a>
                                    </p>
                                    <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro aperiam eveniet...</p>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="col-md-6 col-lg-4 portfolio-img filter web">
                            <figure class="effect-zoe">
                                <img src="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" alt=""/>
                                <figcaption>
                                    <p class="title">John <span>Doe</span></p>
                                    <p class="icon">                                       
                                        <a  href="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" class="portfolio-gallery" title="John Doe"><i class="icon-size-fullscreen"></i></a>
                                    </p>
                                    <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro aperiam eveniet...</p>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="col-md-6 col-lg-4 portfolio-img filter mobile">
                            <figure class="effect-zoe">
                                <img src="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" alt=""/>
                                <figcaption>
                                    <p class="title">John <span>Doe</span></p>
                                    <p class="icon">
                                       
                                        <a  href="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" class="portfolio-gallery" title="John Doe"><i class="icon-size-fullscreen"></i></a>
                                    </p>
                                    <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro aperiam eveniet...</p>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="col-md-6 col-lg-4 portfolio-img filter mobile">
                            <figure class="effect-zoe">
                                <img src="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" alt=""/>
                                <figcaption>
                                    <p class="title">John <span>Doe</span></p>
                                    <p class="icon">
                                        
                                        <a  href="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" class="portfolio-gallery" title="John Doe"><i class="icon-size-fullscreen"></i></a>
                                    </p>
                                    <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro aperiam eveniet...</p>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="col-md-6 col-lg-4 portfolio-img filter web">
                            <figure class="effect-zoe">
                                <img src="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" alt=""/>
                                <figcaption>
                                    <p class="title">John <span>Doe</span></p>
                                    <p class="icon">
                                       
                                        <a  href="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" class="portfolio-gallery" title="John Doe"><i class="icon-size-fullscreen"></i></a>
                                    </p>
                                    <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro aperiam eveniet...</p>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="col-md-6 col-lg-4 portfolio-img filter design">
                            <figure class="effect-zoe">
                                <img src="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" alt=""/>
                                <figcaption>
                                    <p class="title">John <span>Doe</span></p>
                                    <p class="icon">
                                       
                                        <a  href="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" class="portfolio-gallery" title="John Doe"><i class="icon-size-fullscreen"></i></a>
                                    </p>
                                    <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro aperiam eveniet...</p>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="col-md-6 col-lg-4 portfolio-img filter design">
                            <figure class="effect-zoe">
                                <img src="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" alt=""/>
                                <figcaption>
                                    <p class="title">John <span>Doe</span></p>
                                    <p class="icon">
                                        
                                        <a  href="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" class="portfolio-gallery" title="John Doe"><i class="icon-size-fullscreen"></i></a>
                                    </p>
                                    <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro aperiam eveniet...</p>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="col-md-6 col-lg-4 portfolio-img filter design">
                            <figure class="effect-zoe">
                                <img src="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" alt=""/>
                                <figcaption>
                                    <p class="title">John <span>Doe</span></p>
                                    <p class="icon">
                                        
                                        <a  href="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" class="portfolio-gallery" title="John Doe"><i class="icon-size-fullscreen"></i></a>
                                    </p>
                                    <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro aperiam eveniet...</p>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="col-md-6 col-lg-4 portfolio-img filter design">
                            <figure class="effect-zoe">
                                <img src="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" alt=""/>
                                <figcaption>
                                    <p class="title">John <span>Doe</span></p>
                                    <p class="icon">
                                        
                                        <a  href="<?php echo URL;?>/public/images/website/photogallery/portfolio-1.jpg" class="portfolio-gallery" title="John Doe"><i class="icon-size-fullscreen"></i></a>
                                    </p>
                                    <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro aperiam eveniet...</p>
                                </figcaption>
                            </figure>
                        </li>
                    </ul>
                </div>
            </div> 
        </div><!-- End Portfolio Section -->
</div>
        
        <!-- End Page Section -->

        <!-- Start Footer Section -->
       