
            <div class="row mt-5">
                <div class="col-lg-12">
                    <div class="section-block"></div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-12">
                    <h3 class="widget-title">My Profile</h3>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-8">
                        
                            
                        
                    <div class="profile-detail pb-5">
                        <ul class="list-items">
                            
                            <li><span class="profile-name">Student ID:</span><span class="profile-desc"><?php echo $this->studentid;?></span></li>
                            <li><span class="profile-name">Registration Date:</span><span class="profile-desc"><?php echo $this->regtime;?></span></li>
                            <li><span class="profile-name">Full Name:</span><span class="profile-desc"><?php echo $this->studentname;?></span></li>
                            
                            
                            <li><span class="profile-name">Email:</span><span class="profile-desc"><?php echo $this->mail;?></span></li>
                            <li><span class="profile-name">Phone Number:</span><span class="profile-desc"><?php echo $this->mobile;?></span></li>
                            
                        </ul>
                    </div>
                </div><!-- end col-lg-8 -->
            </div><!-- end row -->
    