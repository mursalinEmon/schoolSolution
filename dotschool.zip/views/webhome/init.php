

<!--================================
         START SLIDER AREA
=================================-->
<!-- 2nd Home Slider -->
<div class="home2-slider">
		<div class="container-fluid p0">
			<div class="row">
				<div class="col-lg-12">
					<div class="main-banner-wrapper">
					    <div class="banner-style-one">
					        <div class="slide slide-one sh2" style="background-image: url(assets/images/online-class.jpg);height: 500px;width:100%;">
					            <div class="container">
					                <div class="row">
					                    <div class="col-lg-12 text-center">
					                        <h3 class="banner-title">Welcome To Dot School</h3>
					                        <p></p>
					                        <!-- <div class="btn-block">
					                            <a href="#" class="banner-btn">Ready to get Started?</a>
					                        </div> -->
					                    </div>
					                </div>
					            </div>
					        </div>
					        <div class="slide slide-one sh2" style="background-image: url(assets/images/computer-lab.jpg);height: 500px;width:100%;">
					            <div class="container">
					                <div class="row">
					                    <div class="col-lg-12 text-center">
										<h3 class="banner-title">Welcome To Signaturemind</h3>
					                        <p>Togather we will bring a massive wave of evolution on learning things on different ways</p>
					                        
					                    </div>
					                </div>
					            </div>
					        </div>
					        <div class="slide slide-one sh2" style="background-image: url(assets/images/computer-lab.jpg); height: 500px;width:100%;">
					            <div class="container">
					                <div class="row">
					                    <div class="col-lg-12 text-center">
										<h3 class="banner-title">Welcome To Signaturemind</h3>
					                        <p>Togather we will bring a massive wave of evolution on learning things on different ways</p>
					                        
					                    </div>
					                </div>
					            </div>
					        </div>
					    </div>
					    <!-- <div class="carousel-btn-block banner-carousel-btn">
					        <span class="carousel-btn left-btn"><i class="flaticon-left-arrow left"></i> <span class="left">PR <br> EV</span></span>
					        <span class="carousel-btn right-btn"><span class="right">NE <br> XT</span> <i class="flaticon-right-arrow-1 right"></i></span>
					    </div> -->
					</div><!-- /.main-banner-wrapper -->
				</div>
			</div>
		</div>
	</div>


	