<div class="wrapper">
<div class="light-background">
            <div class="layer-stretch">
                <div class="layer-wrapper pb-0">
                    <div class="row pt-4">
                        <div class="col-12">
                            <div class="panel panel-default">
                                <div class="panel-head">
                                    <div class="panel-title">Cart Detail</div>
                                </div>
                                <div class="panel-wrapper">
                                    <div class="panel-body">
                                        <div class="row table-responsive">
                                        <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th></th>                                                
                                                <th>Description</th>
                                                <th class="text-right">Price</th>
                                                <th class="text-right">Qty</th>
                                                <th class="text-right">Total</th>
                                                <th class="text-center"></th>
                                            </tr>
                                        </thead>
                                        <tbody id="tblcart">                                            
                                            
                                            
                                        </tbody>
                                    </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-footer">
                                <div class="panel-wrapper">
                                    <ul>
                                        <li class="row align-items-center">
                                            <div class="col-6">
                                                <a href="<?php echo URL;?>customerlogin"><button  class="btn btn-success text-white text-center" disabled="true" id="confirmcheckout"><strong><i class="far fa-check-circle"></i>&nbsp; Confirm Checkout </strong></button></a>
                                            </div>
                                            <div class="col-6 text-right">
                                                <p class="font-dosis font-20 m-0" id="gtotal">Total : BDT 0</p>
                                            </div>
                                        </li>
                                    </ul>
                                    </div>
                                </div>
                        </div>
                    </div>    
            </div>
    </div>
</div>