<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Dot DBA</title>
    <link rel="stylesheet" href="<?php echo URL;?>public/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo URL;?>public/css/easy-autocomplete.min.css"> 
    <link rel="stylesheet" href="<?php echo URL;?>public/css/style.css">
    <script>
				<?php

				  $uri = URL;
				  echo "var baseuri = '{$uri}';";

				?>
		</script>
  </head>
  <body>

      <div class="header">
          <h2>DOT Database Editor</h2>
      </div>

      <div class="container ">