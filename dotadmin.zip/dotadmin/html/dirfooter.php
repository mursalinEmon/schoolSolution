
    <footer class="footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
		  <img style="height:50px" src="<?php echo URL; ?>\public\images\biz\100.png" class="user-image" alt="User Image">&copy;&nbsp;DOT BD SOLUTIONS
            
          </div>
          <div class="col-lg-4">
            
          </div>
          <div class="col-lg-4 divrighttext">
            <p class="text-muted"><strong><i><small>POWERED BY DOT BD SOLUTIONS</small></i></strong></p>
          </div>
        </div> 
      </div>
    </footer>
    
    </body>
</html>