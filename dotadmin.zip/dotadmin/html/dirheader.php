<!DOCTYPE html>
<html lang="en">
    <head>
              <meta charset="utf-8">
              <meta http-equiv="X-UA-Compatible" content="IE=edge">
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
              <meta name="description" content="">
              <meta name="author" content="">
              <!-- <link rel="stylesheet" href="<?php echo URL; ?>asset_admin/dist/css/style.css" /> -->
              <link href="<?php echo URL; ?>public/css/bootstrap.min.css" rel="stylesheet">
              <link href="<?php echo URL; ?>public/css/sticky-footer-navbar.css" rel="stylesheet">
              <link href="<?php echo URL; ?>public/css/navbarcustom.css" rel="stylesheet">              
              <link rel="stylesheet" href="<?php echo URL; ?>public/css/login.css">            
          
    </head>
    <body style="padding: 0;margin: 0;">