<?php

$text = 'Anything';

?>